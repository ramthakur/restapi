##Readme File##

###Instruction for the use of the Api rest methods###

###Below are the file strcture given for the Api rest methods###

###FOLDER STRCTURE###

- [rest_methods(Root Folder)]
        |
        [article]
            |
           getArticle.php
        
        [authentication]
            | 
            user-authentication.php
        
        [events]
            |
           getevents.php
      
        [health_library]
            |
            health_library.php
            
        [healthtracker]
            |
            healthtracker.php
            
        [mood_chart]
            |
            mood_chart.php
            
        [newsletter]
            |
            newsletter.php
            
        [profile]
            bmi.php
        
        config.php
        index.php
        readme.md
            
            
    *Instructions for how to use the rest methods*
    
    Step:->   1. To use the rest methods in any file u need to make the config file available to the rest methods
         make the proper path for the config file as the file hierarchy
         for e.g in index file the config.php file is include('config.php') . Beacuse this file is in same directory as in which index file present ,
        , so just simple include the confg.php file
    
    Step:->  2. To use the rest method paste any one of the method in your file with appropiate argument lists
             - Arguments list are as follows for each and every methods
             
            A. [for articles]
                echo Articles::showArticle("article","wellness","102","admin","9ffdfc8661b72a63ff3645af270e19bb6cc0b75a","771e29074bde95e38f13ba3ee0eb95");
                
                Argument 1 [Name of service to be called]
                Argument 2 [Type of Article to be fetched e.g(wellness,fitness,etc)]
                Argument 3 [User id (i.e get form the joomla dashboard in the article manager section)]
                Argument 4 [joomla dashboard username i.e is used for getting the access token]
                Argument 5 [Api access token (unique key)]
                Argument 6 [Api security key (unique key for each and every user)]
            
            B. [for events]
                echo Events::showEvents("calander","all","admin","9ffdfc8661b72a63ff3645af270e19bb6cc0b75a","771e29074bde95e38f13ba3ee0eb95");
                
                Argument 1 [Name of service to be called]
                Argument 2 [Type of event to be fetched e.g(all,yearly,month)]
                Argument 3 [joomla dashboard username i.e is used for getting the access token]
                Argument 4 [Api access token (unique key)]
                Argument 5 [Api security key (unique key for each and every user)]
            C.
                [for news]
                echo News::showNews("newsletter","102","admin","9ffdfc8661b72a63ff3645af270e19bb6cc0b75a","771e29074bde95e38f13ba3ee0eb95");
                
                Argument 1 [Name of service to be called]
                Argument 2 [User id (i.e get form the joomla dashboard in the article manager section)]
                Argument 3 [joomla dashboard username i.e is used for getting the access token]
                Argument 4 [Api access token (unique key)]
                Argument 5 [Api security key (unique key for each and every user)]
            D.
                [for health library]
                echo Library::showlibrary("healtylibrary","Smoking_Center","admin","9ffdfc8661b72a63ff3645af270e19bb6cc0b75a","17","771e29074bde95e38f13ba3ee0eb95");
                
                Argument 1 [Name of service to be called]
                Argument 2 [Type of library to be fetched e.g(Smoking_Center,Natural_Alternative_Treatments,Medications)]
                Argument 3 [joomla dashboard username i.e is used for getting the access token]
                Argument 4 [Api access token (unique key)]
                Argument 5 [id (i.e get form the joomla dashboard in the article manager section)]
                Argument 6 [Api security key (unique key for each and every user)]
            E.
                [for profile bmi tracker]
                echo Profile::bmi("profile","80","1.81","9ffdfc8661b72a63ff3645af270e19bb6cc0b75a","771e29074bde95e38f13ba3ee0eb95");
                
                Argument 1 [Name of service to be called]
                Argument 2 [Weight in kilo grams(1 pound =  0.453592 kg)]
                Argument 3 [height in meter (1 meter = 3.28084 foot)]
                Argument 4 [Api access token (unique key)]
                Argument 5 [Api security key (unique key for each and every user)]
            F.
                [for profile health tracker]
                echo Healthtracher::tracker("healthtracker","custom_tracker","9ffdfc8661b72a63ff3645af270e19bb6cc0b75a","771e29074bde95e38f13ba3ee0eb95");
                
                Argument 1 [Name of service to be called]
                Argument 2 [Type of tracker to be called e.g(food_tracker,exercise_tracker,nutrition_tracker)]
                Argument 3 [Api access token (unique key)]
                Argument 4 [Api security key (unique key for each and every user)]
            G.
                [for mood chart]
                echo Moodchart::chart("mood_chart","2,5,4,5,1,4,5,3","624c021167ad9b30e9ec30681f35b8a301fbb78e","771e29074bde95e38f13ba3ee0eb95");
                
                Argument 1 [Name of service to be called]
                Argument 2 [graph argument list to be passed e.g(for x and y axis points)]
                Argument 3 [Api access token (unique key)]
                Argument 4 [Api security key (unique key for each and every user)]
            H.
                [for user authentication]
                echo UserAuthentication::authentication("client_credentials","admin","123","4cce7adcd885ad17f501e24af75b34");
                
                Argument 1 [client_credentials is fixed for all type user to get the access token using this method (case senstive)]
                Argument 2 [username is same as joomla dashboard username]
                Argument 3 [password is same as joomla dashboard password]
                Argument 4 [Api security key (get form joomla dashbord in Api control pannel section)]
                
                
                
                
                
            
                