<?php
/***
        * The main configuration file which in nesssery to include 
        * where the REST API METHODS needs to be call
**/


//defining the common ENdPOINT 
define('ENDPOINT','http://119.81.53.82/api/v1/'); //replace 
define('AUTHENTICATIONURL','http://119.81.53.82/api/oauth/token.php');
define('API_SECRET_KEY','4cce7adcd885ad17f501e24af75b34');

class ExtractData{
    
    //defining the function to hit the REST API SERVER
    protected function url_hit($url){
    $ch = curl_init(); //initalise the curl 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //setting the option to the curl 
	curl_setopt($ch, CURLOPT_URL,$url);
	$content = curl_exec($ch); 
	return($content);//send response back to function
    }
    
}// ExtractData Class closed here....


class JsonApiMethods extends ExtractData {
    
    //showArticle Methods is defined here
    static function showArticle($serviceId,$serviceType,$userId,$username,$accessToken,$apiSecurityKey) {
    $userUrl = "/getArticle?type=".$serviceType."&userid=".$userId."&client_id=".$username."&access_token=".$accessToken."&api_security_key=".$apiSecurityKey."";
    $response_url = ENDPOINT.$serviceId.$userUrl;
    echo $url = parent::url_hit($response_url);
    }
    //showEvents Methods is defined here
    static function showEvents($serviceId,$eventType,$userID,$accessToken,$apiSecurityKey) {
        $userUrl = "/getevents?mode=".$eventType."&user=".$userID."&access_token=".$accessToken."&api_security_key=".$apiSecurityKey."";
        $main_url = ENDPOINT.$serviceId.$userUrl;
        echo $url = parent::url_hit($main_url);
    }
    //showlibrary Method is defined here
    static function showlibrary($serviceId,$libraryType,$userId,$accessToken,$libraryId,$apiSecurityKey) {
        $userUrl = "/getlib?category=".$libraryType."&user=".$userId."&access_token=".$accessToken."&id=".$libraryId."&api_security_key=".$apiSecurityKey."";
        $main_url = ENDPOINT.$serviceId.$userUrl;
        echo $url = parent::url_hit($main_url);
    }
    //healthTracker Method is defined here
    static function tracker($serviceId,$trackerType,$accessToken,$apiSecurityKey) {
        $userUrl = "/tracker?type=".$trackerType."&access_token=".$accessToken."&api_security_key=".$apiSecurityKey."";
        $main_url = ENDPOINT.$serviceId.$userUrl;
        echo $url = parent::url_hit($main_url);
    }
    //MoodChart Method is defined Here
    static function chart($serviceId,$moodChartValues,$accessToken,$apiSecurityKey) {
        $userUrl = "/chart?values=(".$moodChartValues.")&access_token=".$accessToken."&api_security_key=".$apiSecurityKey."";
        $main_url = ENDPOINT.$serviceId.$userUrl;
        echo $url = parent::url_hit($main_url);
    }
    //ShowNews Method is defined here
    static function showNews($serviceId,$userId,$username,$accessToken,$apiSecurityKey) {
        $userUrl = "/getnews?&userid=".$userId."&client_id=".$username."&access_token=".$accessToken."&api_security_key=".$apiSecurityKey."";
        $main_url = ENDPOINT.$serviceId.$userUrl;
        echo $url = parent::url_hit($main_url);
    }
    //Profile Bmi Calculator Function is defineed here
    static function bmi($serviceId,$weight,$height,$accessToken,$apiSecurityKey) {
        $userUrl = "/bmi?weight_in_kg=".$weight."&height_in_mt=".$height."&access_token=".$accessToken."&api_security_key=".$apiSecurityKey."";
        $main_url = ENDPOINT.$serviceId.$userUrl;
        echo $url = parent::url_hit($main_url);
    }
    //media library method declared here ..

    static function media($username,$accessToken,$apiSecurityKey,$mode) {
        $userUrl = "multimedia/getmedia?client_id=".$username."&access_token=".$accessToken."&api_security_key=".$apiSecurityKey."&mode=".$mode."";
        $main_url = ENDPOINT.$userUrl;
        echo $url = parent::url_hit($main_url);
    }    

    static function authentication($grantType,$clientId,$clientSecret,$apiSecretKey) {
    // Get cURL resource
    $curl = curl_init();
    // Set some options - we are passing in a useragent too here
    curl_setopt_array($curl, array(
           CURLOPT_RETURNTRANSFER => 1,
           CURLOPT_URL => AUTHENTICATIONURL,
           CURLOPT_USERAGENT => 'user Sample cURL Request',
           CURLOPT_POST => 1,
           CURLOPT_POSTFIELDS => array(
               'grant_type' => $grantType,
               'client_id' => $clientId,
               'client_secret'=> $clientSecret,
               'api_secret_key'=>$apiSecretKey
           )
       ));
    // Send the request & save response to $resp
    $resp = curl_exec($curl);
    return ($resp);
    // Close request to clear up some resources
    curl_close($curl);
    }
       
}//Json APi methods is closed ..

?>









