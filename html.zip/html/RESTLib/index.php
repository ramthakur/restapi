<?php

include_once('config.php');

//for article
#echo JsonApiMethods::showArticle("article","wellness","102","admin","f04d4f55f4bba43e022db8ea36ba6c1d5e6bb7b2",API_SECRET_KEY);

//for events
#echo JsonApiMethods::showEvents("calander","all","admin","f04d4f55f4bba43e022db8ea36ba6c1d5e6bb7b2",API_SECRET_KEY);

//for news 
#echo JsonApiMethods::showNews("newsletter","102","admin","f04d4f55f4bba43e022db8ea36ba6c1d5e6bb7b2",API_SECRET_KEY);

//for health library
#echo JsonApiMethods::showlibrary("healtylibrary","Smoking_Center","admin","f04d4f55f4bba43e022db8ea36ba6c1d5e6bb7b2","17",API_SECRET_KEY);

//for profile bmi tracker
#echo JsonApiMethods::bmi("profile","80","1.81","f04d4f55f4bba43e022db8ea36ba6c1d5e6bb7b2",API_SECRET_KEY);

//for profile health tracker
#echo JsonApiMethods::tracker("healthtracker","custom_tracker","f04d4f55f4bba43e022db8ea36ba6c1d5e6bb7b2",API_SECRET_KEY);

//for mood chart
//echo JsonApiMethods::chart("mood_chart","2,5,4,5,1,4,5,3","f04d4f55f4bba43e022db8ea36ba6c1d5e6bb7b2",API_SECRET_KEY);

//user authentication
//echo JsonApiMethods::authentication("client_credentials","admin","123",API_SECRET_KEY);

//media library method 
//echo file_get_contents("http://119.81.53.82/api/v1/multimedia/getmedia?client_id=admin&access_token=9ae60a053497e30b37fa289d01c84b44caf85d2a&api_security_key=d8b26f4cd8c3db22b73730288fdd22&mode=fetch");

?>

